package com.yye.kamiweather.gson;

public class Weather {
    public String updateTime;
    public String fxLink;
    public Now now;

}
