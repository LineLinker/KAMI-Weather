package com.yye.kamiweather.gson;

import com.google.gson.annotations.SerializedName;

public class Now {

    public String temp;
    public String feelsLike;
    public String humidity;
    public String text;
    public String windScale;
    public String pressure;
    public String windDir;

}
