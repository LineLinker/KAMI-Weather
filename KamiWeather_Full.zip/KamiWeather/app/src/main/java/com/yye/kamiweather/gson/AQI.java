package com.yye.kamiweather.gson;

public class AQI {
    public String aqi="default ";
    public String pm2p5="default ";

    public String getAqi(){
        return aqi;
    }

    public void setAqi(String aqi){this.aqi=aqi;}

    public String getPm2p5(){
        return aqi;
    }

    public void setPm2p5(String pm2p5){
        this.pm2p5=pm2p5;
    }
}

